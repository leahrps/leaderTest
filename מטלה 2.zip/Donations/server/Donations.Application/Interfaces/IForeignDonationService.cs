﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Donations.Application.Models;

namespace Donations.Application
{
    public interface IForeignDonationService
    {
        Task Add(ForeignDonation foreignDonation);
        Task<ForeignDonation> Get(int id);
        Task<List<ForeignDonation>> GetAll();
        Task Update(ForeignDonation foreignDonation);
        Task Delete(int id);
    }
}
