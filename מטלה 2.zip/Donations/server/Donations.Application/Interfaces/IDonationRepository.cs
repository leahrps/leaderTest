﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Donations.Application.Models;

namespace Donations.Application.Interfaces
{
    public interface IDonationRepository
    {
        
        Task Add(ForeignDonation foreignDonation);
        Task Update(ForeignDonation foreignDonation);
        Task Delete(int id);
        Task<ForeignDonation> Get(int id);
        Task<List<ForeignDonation>> GetAll();
    }
}
