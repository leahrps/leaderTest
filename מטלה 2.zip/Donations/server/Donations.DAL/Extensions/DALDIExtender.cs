﻿using Donations.Application.Interfaces;
using Donations.DAL;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;

namespace Microsoft.Extensions.DependencyInjection
{
    public static class DALDIExtender
    {
        public static IServiceCollection AddDALServices(this IServiceCollection services)
        {
            services.AddTransient<IDonationRepository, DonationRepository>();


            return services;
        }
    }
}
