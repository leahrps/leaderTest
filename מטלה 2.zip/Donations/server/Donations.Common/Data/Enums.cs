﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace Donations.Common.Data
{
    public class Enums
    {
        public enum EntityTypes
        {
            ForeignCountry1,
            ForeignCountry2,
            ForeignCountry3,
            ForeignCountry4,
            ForeignCountry5
        }
        public enum CoinTypes
        {
            USD,
            EUR,
            GBP

        }
        public enum Errors
        {
            [Description("Error unhanded exception occurred")]
            UnManaged = 500,

            [Description("Donation with ID:{0}, not found in repository")]
            IdNotFoundInRepository = 1000,

            [Description("Mail sending failed")]
            SendMailFailed = 1001


        }
        

    }
}
