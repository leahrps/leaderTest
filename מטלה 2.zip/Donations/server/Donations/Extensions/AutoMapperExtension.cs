﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Donations.Mapper;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Donations.Extensions
{
    public static class AutoMapperExtension
    {
        public static void AddAutoMapperExtension(this IServiceCollection services, IConfiguration configuration)
        {
            AddAutoMapperProfiles(services);
        }
        private static void AddAutoMapperProfiles(IServiceCollection services)
        {
            //The AutoMapper provides only single point of registration
            //thus we have to register all profiles once
            var mappingConfig = new MapperConfiguration(mc =>
            {
                mc.AddProfile(new AutoMapperProfile());
            });

            IMapper mapper = mappingConfig.CreateMapper();
            services.AddSingleton(mapper);
        }
    }
}
