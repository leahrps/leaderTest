﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace Donations.Extensions
{
    public static class ResponseFormatter
    {
        public static ContentResult ToHtmlResponse(this string contentToResponse)
        {
            var result = new ContentResult()
            {
                Content = contentToResponse,
                ContentType = "text/html;charset=utf-8",
                StatusCode = 200

            };
            return result;
        }


        public static JsonResult ToJsonResponse(this string jsonResponse)
        {
            var result = new JsonResult(jsonResponse);
            result.StatusCode = 200;
            result.ContentType = "application/json";
            return result;
        }


        public static JsonResult ToJsonResponse(this object objToResponse)
        {
            var result = new JsonResult(objToResponse);
            result.StatusCode = 200;
            result.ContentType = "application/json";
            return result;
        }
    }
}
