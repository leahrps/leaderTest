﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Donations.DTO
{
    public class ForeignDonation:IDTO
    {
        public int Id { get; set; }
        [Required]
        [RegularExpression("^[A-Za-zא-ת]*$")]
        public string EntityName { get; set; }
        [Required]
        public double DonationAmount { get; set; }
        [Required]
        public string EntityType { get; set; }
        [Required]
        [RegularExpression("^[A-Za-zא-ת]*$")]
        public string Designation { get; set; }
        [RegularExpression("^[A-Za-zא-ת]*$")]
        public string Condotions { get; set; }
        [Required]
        public string CoinType { get; set; }
        [Required]
        public float ConversionRate { get; set; }
    }
}
