﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Donations.Controllers
{
    [ApiController]
    public class BaseController : ControllerBase
    {
        private readonly ILogger _logger;
        private readonly IMapper _mapper;
        //private readonly Identity _identity;

        protected ILogger Logger => _logger;


        /// <summary>
        /// Authenticated User Identity object. Provide Functionalit On UserInfo and UserInfo Model
        /// </summary>
        //protected Identity Identity => _identity;

        protected IMapper Mapper => _mapper;


        public BaseController(ILogger logger,
                              IMapper mapper)
        {
            _logger = logger;
            _mapper = mapper;


            //_identity = authenticationService.GetUserIdentity();
            //if (_identity == null)
            //    throw new AuthenticationException(GovForms.Manager.ExportData.Common.Data.Enums.Errors.UserNotFound.GetDescritpion(),
            //                           GovForms.Manager.ExportData.Common.Data.Enums.Errors.UserNotFound.GetHashCode());

        }
    }
}