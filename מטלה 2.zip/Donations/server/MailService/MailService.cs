﻿using System;
using System.IO;
using System.Net.Mail;
using Donations.Application.Interfaces;
using Donations.Application.Models;

namespace Donations.MailService
{
    public class MailService:IMailService
    {
        private readonly string m_HostServer;

        private readonly string m_SenderAddress;

        public MailService()
            : this("smtp.gmail.com", "DoNotRespond@donations.com")
        {
        }

        public MailService(string host, string sender)
        {
            m_HostServer = host;

            m_SenderAddress = sender;
        }

        public bool SendMail(MailData mailData)
        {
            var client = CreateSmtpClient();

            var mail = new MailMessage(m_SenderAddress, mailData.To);
            mail.Subject = mailData.Subject;
            mail.Body = mailData.Body;


            try
            {
                client.Send(mail);
            }
            catch (Exception ex)
            {

                var inner = ex;

                while (inner.InnerException != null) inner = inner.InnerException;

                //Logger.Log("Exception occurred: " + ex.Message);

                return false;
            }

            return true;
        }

        private SmtpClient CreateSmtpClient()
        {
            var client = new SmtpClient
            {
                Port = 25,
                DeliveryMethod = SmtpDeliveryMethod.Network,
                UseDefaultCredentials = false,
                Host = m_HostServer
            };

            return client;
        }
    }
}
