﻿using Donations.Application.Interfaces;
using Donations.MailService;
using System;
using System.Collections.Generic;
using System.Text;

namespace Microsoft.Extensions.DependencyInjection
{
    public static class MailServiceDIExtender
    {
        public static IServiceCollection AddMailServiceServices(this IServiceCollection services)
        {
            services.AddTransient<IMailService, MailService>();


            return services;
        }
    }
}
