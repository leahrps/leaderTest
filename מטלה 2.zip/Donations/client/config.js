require.config({
    baseUrl: '/src/',
    waitSeconds: 40,
    paths: {
        pages: './pages',
        components: './components',
        knockout: '../node_modules/knockout/build/output/knockout-latest.debug',
        jquery: '../node_modules/jquery/dist/jquery',
        'jquery-ui-dist': '../node_modules/jquery-ui-dist/jquery-ui',
        sammy: '../node_modules/sammy/lib/sammy',
        mapping: '../node_modules/knockout.mapping/knockout.mapping',
        'knockout-postbox': '../node_modules/knockout-postbox/build/knockout-postbox',
        validation: './extenrals/knockout.validation',
        underscore: '../node_modules/underscore/underscore',
        q: '../node_modules/q/q'
    },
    shim: {
        knockout: {
            exports: 'ko'
        },
        mapping: {
            deps: ['knockout'],
            exports: 'mapping'
        },
        'knockout-postbox': {
            deps: ['knockout']
        },
        validation: {
            deps: ['knockout']
        }
    },
    deps: ['knockout', 'mapping'],
    callback: (ko, mapping) => {
        ko.mapping = mapping;
    }

});

