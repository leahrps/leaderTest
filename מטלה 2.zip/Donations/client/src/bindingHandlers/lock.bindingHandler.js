﻿define(['knockout'], (ko) => {//eslint-disable-line
    var elementsResources = {  
        disabledAttr: 'disabled',
        dataDisabledAttr: 'data-disabled',
        lockClassName: 'lock',
        lockSelector: '.lock',
        neverLock: 'neverLock',
        neverLockSelector: '.neverLock'
    };

    var addDisabledAttr = function (element, isNotExistParentLock) {
        var externalDisabled = $(element).attr(elementsResources.disabledAttr);
        if (externalDisabled && isNotExistParentLock) {
            $(element).attr(elementsResources.dataDisabledAttr, externalDisabled);
        }
        $(element).attr(elementsResources.disabledAttr, 'disabled');
    };

    var removeDisabledAttr = function (element, isNotExistParentLock) {
        var externalDisabled = $(element).attr(elementsResources.dataDisabledAttr);
        if (externalDisabled && isNotExistParentLock) {
            $(element).attr(elementsResources.disabledAttr, externalDisabled);
            $(element).removeAttr(elementsResources.dataDisabledAttr);
        }
        else if (isNotExistParentLock) {
            $(element).removeAttr(elementsResources.disabledAttr);
        }
    };

    var isFirstElementLock = function (lockParentsNumber, isElementLocked) {
        return (lockParentsNumber === 1 && !isElementLocked) || (lockParentsNumber === 0 && isElementLocked);
    };

    var isNeverLockElement = function (element) {
        return $(element).parents(elementsResources.neverLockSelector).length > 0 || $(element).hasClass(elementsResources.neverLock);
    };

    var toggleDisabledAttr = function (element, needLock) {
        if (isNeverLockElement(element)) {
            removeDisabledAttr(element, true);
            return;
        }
        var isNotExistLock;
        var lockParentsNumber = $(element).parents(elementsResources.lockSelector).length;
        var isElementLocked = $(element).hasClass(elementsResources.lockClassName);
        if (needLock) {
            isNotExistLock = isFirstElementLock(lockParentsNumber, isElementLocked);
            addDisabledAttr(element, isNotExistLock);


        }
        else if (needLock === false) {
            isNotExistLock = lockParentsNumber === 0 && !isElementLocked;

            removeDisabledAttr(element, isNotExistLock);
        }
    };

    var handleChildrenDisabledAttr = function (element, needLock) {
        $(element).find('*').not('div,label,a').each(function (index, elem) {
            toggleDisabledAttr(elem, needLock);
        });
    };

  
    var toggleLockClass = function (element, needLock) {
        if (needLock) {
            $(element).addClass(elementsResources.lockClassName);
        }
        else if (needLock === false) {
            $(element).removeClass(elementsResources.lockClassName);
        }
    };

    var handleLockBehavior = function (element, needLock) {
        toggleLockClass(element, needLock);
        toggleDisabledAttr(element, needLock);
        handleChildrenDisabledAttr(element, needLock);
    };


    var isExist = function isExist(element) {
        return ($(element) && $(element).length);
    };

    /**     
     * @memberof ko         
     * @function "ko.bindingHandlers.lock"
     * @description custom binding for enabled or disabled inputs.
     * @example 
     * lock: viewModel.isInputLock
   */
    ko.bindingHandlers.lock = {
        update: function (element, valueAccessor) {
            var value = valueAccessor();
            var valueUnwrapped = ko.unwrap(value);
            var isNeverLock = $(element).hasClass(elementsResources.neverLock);
            if (!isNeverLock) {
                handleLockBehavior(element, valueUnwrapped);
            }
            if (isNeverLock) {
                handleLockBehavior(element, false);
            }
        }
    };
});

