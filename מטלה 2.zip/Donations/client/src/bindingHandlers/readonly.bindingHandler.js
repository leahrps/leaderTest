﻿define(['knockout'], (ko) => {//eslint-disable-line
    var elementsResources = {
        readonlyAttr: 'readonly',
        dataDisabledAttr: 'data-disabled',
        lockClassName: 'lock',
        lockSelector: '.lock',
        neverLock: 'neverReadonly',
        neverLockSelector: '.neverReadonly'
    };

    var addReadonlyAttr = function (element, isNotExistParentLock) {
        $(element).attr(elementsResources.readonlyAttr, '');
    };

    var removeReadonlyAttr = function (element, isNotExistParentLock) {
        if (isNotExistParentLock) {
            $(element).removeAttr(elementsResources.readonlyAttr);
        }
    };

    var isFirstElementLock = function (lockParentsNumber, isElementLocked) {
        return (lockParentsNumber === 1 && !isElementLocked) || (lockParentsNumber === 0 && isElementLocked);
    };

    var isNeverLockElement = function (element) {
        return $(element).parents(elementsResources.neverLockSelector).length > 0 || $(element).hasClass(elementsResources.neverLock);
    };



    var toggleReadonlyAttr = function (element, needLock) {
        if (isNeverLockElement(element)) {
            removeReadonlyAttr(element, true);
            return;
        }
        var isNotExistLock;
        var lockParentsNumber = $(element).parents(elementsResources.lockSelector).length;
        var isElementLocked = $(element).hasClass(elementsResources.lockClassName);
        if (needLock) {
            isNotExistLock = isFirstElementLock(lockParentsNumber, isElementLocked);
            addReadonlyAttr(element, isNotExistLock);

        }
        else if (needLock === false) {
            isNotExistLock = lockParentsNumber === 0 && !isElementLocked;
            removeReadonlyAttr(element, isNotExistLock);
        }
    };

    var handleChildrenReadonlyAttr = function (element, needLock) {
        $(element).find('input,textarea').each(function (index, elem) {
            toggleReadonlyAttr(elem, needLock);
        });
    };

    var toggleLockClass = function (element, needLock) {
        if (needLock) {
            $(element).addClass(elementsResources.lockClassName);
        }
        else if (needLock === false) {
            $(element).removeClass(elementsResources.lockClassName);
        }
    };

    var handleLockBehavior = function (element, needLock) {
        // toggleLockClass(element, needLock);
        toggleReadonlyAttr(element, needLock);
        handleChildrenReadonlyAttr(element, needLock);
    };


    var isExist = function isExist(element) {
        return ($(element) && $(element).length);
    };

    const originalValueInit = ko.bindingHandlers.value.init;

    ko.bindingHandlers.value.init = function (element, valueAccessor, allBindingsAccessor, data, context) {//eslint-disable-line max-params
        const isHasReadonlyParent = !!$(element).parents('[readonly=readonly]').length;
        if (isHasReadonlyParent) {
            handleLockBehavior(element, true)
        }
        originalValueInit(element, valueAccessor, allBindingsAccessor, data, context);
    };
    /**     
     * @memberof ko         
     * @function "ko.bindingHandlers.lock"
     * @description custom binding for enabled or disabled inputs.
     * @example 
     * lock: viewModel.isInputLock
   */
    ko.bindingHandlers.readonly = {
        update: function (element, valueAccessor) {
            var value = valueAccessor();
            var valueUnwrapped = ko.unwrap(value);
            var isNeverLock = $(element).hasClass(elementsResources.neverLock);
            if (!isNeverLock) {
                handleLockBehavior(element, valueUnwrapped);
            }
            if (isNeverLock) {
                handleLockBehavior(element, false);
            }
        }
    };
});

