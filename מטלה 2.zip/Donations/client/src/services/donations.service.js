﻿
define(['services/ajax'], (ajax) => {

    const  endpoint = 'foreignDonations';

    const getAllDonations = () => {       
        return ajax.request({
            url:`${endpoint}/GetAll`
        }).then(function (data) {
            return data;
        }).catch(function (error) {
            throw new Error(error);
        });
    };
    const getDonation = (routeParams) => {       
        return ajax.request({
            url:`${endpoint}/Get/${routeParams.id}`
        }).then(function (data) {
            return data;
        }).catch(function (error) {
            throw new Error(error);
        });
    };
    const addDonation = (routeParams) => {       
        return ajax.request({
            url:`${endpoint}/Add/${routeParams.data}`
        }).then(function (data) {
            return data;
        }).catch(function (error) {
            throw new Error(error);
        });
    };
    const updateDonation = (routeParams) => {       
        return ajax.request({
            url:`${endpoint}/Update/${routeParams.data}`
        }).then(function (data) {
            return data;
        }).catch(function (error) {
            throw new Error(error);
        });
    };

    return { getAllDonations, getDonation, addDonation,updateDonation};
});