﻿define(['knockout',
    'sammy',
    'pages/error/errorMessages'
],
    function (ko, Sammy) {//eslint-disable-line max-params

        class routing {
            constructor() {
                this.currentPage = ko.observable('').extend({ notify: 'always' });
                this.params = ko.observable().extend({ notify: 'always' });
            }
            gotoErrorPage(errorType) {
                window.location = `#/error/${errorType}`;
            }
            showPage(page, params) {
                this.currentPage(page);
                this.params(params);
            }
            init() {
                const _app = Sammy(app => {

                    app.get('#/', ctx => {
                        ctx.redirect('#/donationsList')
                    });
                    app.get('#/error', ctx => { this.showPage('errorPage', ctx.params) });
                    app.get('#/error/:errorType', ctx => { this.showPage('errorPage', ctx.params) });
                    app.get('#/donationsList', ctx => { this.showPage('donationsList', ctx.params) });
                    app.get('#/newDonation', ctx => { this.showPage('newDonation', ctx.params) });

                    app.notFound = () => { this.gotoErrorPage('notFound'); };
                });
                _app.run('#/donationsList');
            }

        }

        return routing;
    });

