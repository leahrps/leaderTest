﻿define(() => {
    const loadingElements = {
        main: '.container',
        grid: '.data-grid',
        userPermission: '.add-user'
    };

    return loadingElements;
});