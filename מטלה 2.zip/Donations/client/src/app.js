﻿

require(['knockout',
    'models/loginUser.model',
    'routing/routing',
    'ko/bindingHandlers/loader/loader',
    'ko/bindingHandlers/loader/loadingElements',
    'validations/init.validation',
    'pages/DonationsList/DonationsList.page',
    'pages/NewDonation/NewDonation.page',
    'knockout-postbox',
    'jquery',
    'jquery-ui-dist'],
    (ko, loginUserServices, Routing, toggleLoader, loadingElements) => {//eslint-disable-line max-params
        const vm = {
            routing: new Routing()
        };

        const login = () => {
            return loginUserServices
                .getLoginUser()
                .then((data) => {
                    //vm.loginUser(new LoginUser(data));
                })
                .catch(err => {
                    switch (err.status) {
                        case 401:
                        case 403:
                            vm.routing.gotoErrorPage('unauthorized');
                            break;
                        case 400:
                        case 404:
                            vm.routing.gotoErrorPage('notFound')
                            break;
                        default:
                            vm.routing.gotoErrorPage('internalError')
                    }
                })

        }
        const init = () => {
            toggleLoader(loadingElements.main, true);
            vm.routing.init();
            // login().finally(() => {
            //     
            // });
            ko.applyBindings(vm);
        };
        init();
    });
