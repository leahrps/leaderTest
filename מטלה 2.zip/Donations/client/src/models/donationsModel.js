define(['knockout'
, 'models/base.model'
, 'services/donations.service'],
    function (ko, BaseModel, services ) {
        class DonationsModel extends BaseModel {
            constructor(params) {
                super();
                const self = this;
                self.entityName = ko.observable('').extend({required:true, englishHebrew: 'שם הישות' });
                self.donationAmount = ko.observable('').extend({required:true,  number: 'סכום התרומה' });
                self.entityType = ko.observable('');
                self.designation = ko.observable('').extend({required:true,  englishHebrew: 'יעוד התרומה' });
                self.condotions = ko.observable('').extend({ englishHebrew: 'התנאים לתרומה' });
                self.coinType = ko.observable('').extend({required:true });
                self.conversionRate = ko.observable('').extend({required:true });
                self.saveCallback = ()=>{};
                
                const initializeData = (params) => {
                    const {data,saveCallback} = params;
                    self.entityName(data.entityName);
                    self.donationAmount(data.donationAmount);
                    self.designation(data.designation);
                    self.condotions(data.entitcondotionsyName);
                    self.coinType(data.coinType);
                    self.conversionRate(data.conversionRate);
                    self.saveCallback = saveCallback;
                };
                if(params){
                    initializeData(params);
                }
            }
        }
        return DonationsModel;
 });