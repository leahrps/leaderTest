
define(['knockout', 'validation'],
    function (ko) {//eslint-disable-line max-params
        const messages = {
            require: 'שדה חובה',
            maxLength: `יש להזין עד {0} תווים`
        }


        ko.options.deferUpdates = false; // this causes an error with the validation, on clearing the value.

        ko.validation.rules.required.message = messages.require;

        ko.validation.rules.maxLength.message = messages.maxLength;

        ko.validation.init({
            insertMessages: true,
            errorElementClass: 'error',
            decorateInputElement: true,
            decorateElement: true,
            decorateElementOnModified: true
        }, true);

    });