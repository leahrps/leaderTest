define(['knockout', 'validation'], function (ko) {//eslint-disable-line max-params
    ko.validation.rules['englishHebrew'] = {
        validator: function (val) {
            return /^[\sa-zA-Zא-ת]*$/.test(val);
        },
        message: `{0} יכול להכיל אותיות באנגלית ועברית`
    };
    
    ko.validation.rules['number'] = {
        validator: function (val) {
            return /^\d+(\.\d+)?$/.test(val);
        },
        message: `{0} צריך להכיל מספר עשרוני תקני`
    };

    ko.validation.rules['hebrew'] = {
        validator: function (val) {
            if (val)
                return /^([א-ת-',"\s()]*)\s*$/.test(val);
            return true;
        },
        message: `{0} יכול להכיל אותיות בעברית או " ' -  , ()  בלבד`
    };

    ko.validation.rules['englishOnly'] = {
        validator: function (val) {
            if (val)
                return /^[a-zA-Z]+$/.test(val);
            return true;
        },
        message: `{0} יכול להכיל אותיות אנגליות בלבד`
    };

    ko.validation.rules['apostropheAfterLetters'] = {
        validator: function (val) {
            return !/[^זגחצץעת]'/.test(val);
        },
        message: `ניתן להזין גרש (') רק אחרי אותיות אלו: זגחצץעת`
    };

    ko.validation.rules['finalLetters'] = {
        validator: function (val) {
            return !/([םןךףץ][א-ת])/.test(val);
        },
        message: `אותיות סופיות (ך,ם,ן,ף,ץ) יכולות לבוא רק כאות אחרונה`
    };


    ko.validation.registerExtenders();
});

