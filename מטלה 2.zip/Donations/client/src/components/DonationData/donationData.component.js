// import ko from 'knockout';
// import template from './donationData.html';
define(['knockout'
    , 'text!components/donationData/donationData.html'
    , 'services/donations.service'
    , 'validations/language.rule'
],
    function (ko, template,services) {
        class DonationData {
            constructor(params= {}) {
                const {donationData,saveCallback} = params;
                this.donationData = donationData;
                this.saveCallback = saveCallback;
                this.save = () =>{
                    self.saveCallback();
                }
            }   
        }

        ko.components.register('donation-data', { viewModel: DonationData, template });
    });
