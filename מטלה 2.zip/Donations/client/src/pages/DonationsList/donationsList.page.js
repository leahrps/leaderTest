define(['knockout'
    , 'text!pages/donationsList/donationsList.html'
    , 'services/donations.service'
    ,'models/donationsModel'
    ,'Components/DonationData/donationData.component'
],
    function (ko, template, services,DonationsModel) {
        class DonationsModelExpand extends DonationsModel {
            constructor(params) {
                super(params);
                const self = this;
                self.isEditMode = ko.observable(false);
                self.arrowIcon = ko.computed(function () {
                    return self.isEditMode()?"arrow_up2":"arrow_down";
                });
            }
        }
        class donationsList {
            constructor() {
                const self = this;
                self.update = ()  =>{
                    services.updateDonation();
                }

                // hardcoded data
                const donation = new DonationsModelExpand({data:{id : 1, entityName : "יישות אחת", donationAmount : 111.1},saveCallback:this.update});
                self.donations = ko.observableArray([donation]);

                self.mapDonation = (data) => {
                    self.donations([new DonationsModel(data)]);//TODO:map
                };

                this.getDonations = () => {
                    //loading.on();
                    const donationsListPromise = services.getDonationsList();
                    donationsListPromise.then((response = {}) => {
                        if (response.data !== null) {
                            this.mapDonation(response.data);
                        }
                    }).finally(() => {
                        //loading.off();
                    });
                };


            }
        }
    ko.components.register('donations-list-page', { viewModel: donationsList, template });
});