define(['knockout'
    , 'text!pages/newDonation/newDonation.html'
    , 'services/donations.service'
    ,'models/donationsModel'
    ,'Components/DonationData/donationData.component'
],
    function (ko, template, services, DonationsModel) {
        class NewDonation {
            constructor(settings) {
                const self = this;
                self.data = new DonationsModel();

                this.add = ()  =>{
                    if(self.data.validate()){
                        services.addDonation(self.data);
                    }  
                }
            }
        }
        ko.components.register('new-donation-page', { viewModel: NewDonation, template });
});