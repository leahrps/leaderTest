﻿define(['knockout', 'text!ko/bindingHandlers/loader/loadSpan.html'],
    (ko, loadSpan) => {

        const getValueAccessor = (valueAccessor) => {
            let unwrapValue = ko.unwrap(valueAccessor);
            if (typeof (unwrapValue) === 'function') {//eslint-disable-line
                unwrapValue = ko.unwrap(unwrapValue());
            }
            return unwrapValue;
        };

        ko.bindingHandlers.visibleLoader = {
            update: function (element, valueAccessor, allBindings) {//eslint-disable-line
                if (getValueAccessor(valueAccessor)) {
                    $(element).append(loadSpan);

                }
                else {
                    $(element).find('.loader-icon').remove();
                }
                var cssSettingsAccessor = function () {
                    var css = {};
                    css['loader-overlay'] = getValueAccessor(valueAccessor);
                    return css;
                };
                ko.bindingHandlers.css.update(element, cssSettingsAccessor, allBindings);
            }
        };

        const isVisibleLoader = (elementToLoad, isVisible) => {
            if ($(elementToLoad).get(0)) {
                ko.bindingHandlers.visibleLoader.update($(elementToLoad).get(0), isVisible);
            }
        };

        return isVisibleLoader;
    });