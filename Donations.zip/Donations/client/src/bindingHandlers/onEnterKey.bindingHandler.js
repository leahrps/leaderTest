define(['knockout'],
    function (ko) {//eslint-disable-line max-params
       
        ko.bindingHandlers.onEnterKey = {
            init: function (element, valueAccessor, allBindings, viewModel) {//eslint-disable-line max-params

                const _value = ko.unwrap(allBindings()).value;
                const _onKeyPress = ko.unwrap(valueAccessor());


                $(element).off('keypress filter').on('keypress filter', function (e) {

                    var key = e.which;
                    var enterKeyCode = 13;
                    if (key === enterKeyCode) {
                        const _input = $(element).is('input') ? $(element) : $(element).find("input:first");
                        $(_input).change();
                        _value.valueHasMutated();
                        _onKeyPress();
                        e.stopPropagation();
                        return false;
                    }
                });

            }
        };

    });