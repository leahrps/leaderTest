define(['knockout'],
    function (ko) {//eslint-disable-line max-params

        ko.bindingHandlers.focus = {
            init: function (element, valueAccessor, allBindings, viewModel) {
                const _isFocus = valueAccessor();

                element.addEventListener("focusout", () => {
                    const dialog = document.querySelector('[role="dialog"]')
                    const isFocusedDialog = !!dialog && window.getComputedStyle(dialog).display !== 'none';

                    console.log('dialog', isFocusedDialog, document.activeElement);
                    if (!element.matches(':focus-within') && !isFocusedDialog)
                        _isFocus(false);
                });
            },

            update: function (element, valueAccessor, allBindings, viewModel) {//eslint-disable-line max-params

                const _isFocus = ko.unwrap(valueAccessor());

                if (_isFocus) {
                    element.focus();
                }


            }

        }
    });