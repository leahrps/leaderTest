define(['knockout'
    , 'utilities/resetObservables']
    , (ko,  resetModel) => {
    class BaseModel {
        constructor(params = {}) {

        }

        validate() {
    
            var validatedModel = ko.validatedObservable(this, { deep: true });               

            validatedModel.errors.forEach(function (observable) {
                if (observable.autoClearedWrongValue) {
                    observable.valueHasMutated();
                }
            });
            if (validatedModel.errors && validatedModel.errors().length > 0) {
                validatedModel.errors.showAllMessages();
                return false;
            }
            return true;
        }

        reset(ignore = []) {//eslint-disable-line complexity
            resetModel(this);
        };
    }

    return BaseModel;
});