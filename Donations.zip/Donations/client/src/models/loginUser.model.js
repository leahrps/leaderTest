﻿

define(['knockout'], function (ko) {//eslint-disable-line max-params
    class LoginUser {
        constructor(params = {}) {
            const { identity, name, email, units, roles } = params;
            this.identity = identity;
            this.name = name;
            this.email = email;
            this.units = units;
            this.roles = roles.map(role => role.name);
            this.roleChilds = roles.reduce((arr, role) => [...arr, ...role.childs], [])


            const isAdmin = () => {
                return ko.unwrap(this.roles).includes('Admin');
            }
            const isOfficeAdmin = () => {
                return ko.unwrap(this.roles).includes('OfficeAdmin');
            }
            const isReader = () => {
                return ko.unwrap(this.roles).includes('Reader');
            }
            const isOfficeReader = () => {
                return ko.unwrap(this.roles).includes('OfficeReader');
            }

            this.isReader = isReader;
            this.isOfficeReader = isOfficeReader;
            this.isAdmin = isAdmin;
            this.isOfficeAdmin = isOfficeAdmin;
            this.isReadonly = ko.pureComputed(() => {
                const _isAdmin = isAdmin();
                const _isOfficeAdmin = isOfficeAdmin();
                return !_isAdmin && !_isOfficeAdmin;
            });

            this.isAllowedToApplication = (app) => {
                return ko.unwrap(app.roles)
                    .some(rl => this.roleChilds.includes(ko.unwrap(rl.id)));
            }

            this.getAllowedRoles = (app) => {
                return ko.unwrap(app.roles)
                    .filter(rl => this.roleChilds.includes(ko.unwrap(rl.id)));
            }

            this.isAllowedToOffice = (ofc) => {
                return ko.unwrap(ofc.units)
                    .some(unt => this.units.includes(ko.unwrap(unt.id)));
            }
        }
    }

    return LoginUser;
});