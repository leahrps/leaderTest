define(['knockout'
    , 'text!pages/error/error.html'
    , 'pages/error/errorMessages'
],
    function (ko, template, errorMessages) {
        class errorViewModel {
            constructor(params) {
                const { route } = params;
                const _route = ko.unwrap(route);
                this.message = errorMessages[_route.errorType];

            }

        }
        ko.components.register('error-page', { viewModel: errorViewModel, template });

    });


