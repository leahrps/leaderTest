﻿define(() => {
    const messages = {
        unauthorized: 'מצטערים, אין לך הרשאה למערכת זו.',
        notFound: 'אופס! דף לא קיים במערכת',
        unauthorizedPage: 'מצטערים, אין לך הרשאה לדף זה.',
        unauthorizedAction: 'מצטערים, אין לך הרשאה לדף זה.',
        internalError: 'שגיאת מערכת'
    };
    return messages;
});