﻿define(['knockout'], function (ko) {
    const resetObservables = (object, defaultvalue) => {//eslint-disable-line complexity
        for (var key in object) {
            if (object.hasOwnProperty(key)) {
                var property = object[key];
                if (ko.isComputed(property)) {
                    continue;
                }
                if (property && property.hasOwnProperty('ignore')) {
                    continue;
                }
                if (ko.isObservable(property)) {
                    property(defaultvalue);
                }
                if (property && property.hasOwnProperty('isModified')) {
                    property.isModified(false);
                }
                if (property && property.hasOwnProperty('default')) {
                    property(property.default);
                }
            }
        }
    };

    return resetObservables;
});