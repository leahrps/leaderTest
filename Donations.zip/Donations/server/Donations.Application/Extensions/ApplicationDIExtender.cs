﻿using Donations.Application.Interfaces;
using Donations.Application;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;

namespace Microsoft.Extensions.DependencyInjection
{
    public static class ApplicationDIExtender
    {
        public static IServiceCollection AddApplicationServices(this IServiceCollection services)
        {
            services.AddTransient<IForeignDonationService, ForeignDonationService>();


            return services;
        }
    }
}
