﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Donations.Application.Interfaces;
using Donations.Application.Models;
using Donations.Common.Data;
using Microsoft.Extensions.Configuration;

namespace Donations.Application
{
    class ForeignDonationService : IForeignDonationService
    {
        private readonly IDonationRepository _donationRepository;
        private readonly IMailService _mailService;
        private readonly IConfiguration _configuration;
        public async Task Add(ForeignDonation foreignDonation)
        {
            await _donationRepository.Add(foreignDonation);
            if(foreignDonation.DonationAmount> Constants.THANKYOU_EMAIL_AMOUNT)
            {
                sendMail();
            }
        }

        public async Task Delete(int id)
        {
            await _donationRepository.Delete(id);
        }

        public async Task<ForeignDonation> Get(int id)
        {
            return await _donationRepository.Get(id);
        }

        public async Task<List<ForeignDonation>> GetAll()
        {
            return await _donationRepository.GetAll();
        }

        public async Task Update(ForeignDonation newDonation)
        {
            ForeignDonation currentDonation = await _donationRepository.Get(newDonation.Id);
            if (currentDonation == null)
            {
                //throw exception
            }
            await _donationRepository.Update(newDonation);
        }

        private void sendMail()
        {
            
            MailData mailData = new MailData()
            {
                To = "blumigreenberg@gmail.com",
                Subject = Constants.EMAIL_SUBJECT,
                Body = Constants.EMAIL_BODY
            };
            _mailService.SendMail(mailData);
        }
    }
}
