﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Donations.Application.Models;

namespace Donations.Application.Interfaces
{
    public interface IMailService
    {
        bool SendMail(MailData mailData);
    }
}
