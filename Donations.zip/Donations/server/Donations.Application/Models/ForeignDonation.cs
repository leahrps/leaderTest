﻿using System;
using System.Collections.Generic;
using System.Text;
using static Donations.Common.Data.Enums;

namespace Donations.Application.Models
{
    
    public class ForeignDonation
    {
        public int Id { get; set; }
        public string EntityName { get; set; }
        public double DonationAmount { get; set; }
        public EntityTypes EntityType { get; set; }
        public string Designation { get; set; }
        public string Condotions { get; set; }
        public CoinTypes CoinType { get; set; }
        public float ConversionRate { get; set; }

    }
}
