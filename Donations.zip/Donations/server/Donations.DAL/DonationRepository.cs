﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Donations.Application.Interfaces;
using Donations.Application.Models;

namespace Donations.DAL
{
    public class DonationRepository : IDonationRepository
    {
        public Task Add(ForeignDonation foreignDonation)
        {
            throw new NotImplementedException();
        }

        public Task Delete(int id)
        {
            throw new NotImplementedException();
        }

        public Task<ForeignDonation> Get(int id)
        {
            return Task.Run(() =>
            {
                return new ForeignDonation() { Id = id, EntityName = "Got one entity", DonationAmount = 111 };
            });
        }

        public Task<List<ForeignDonation>> GetAll()
        {
            return Task.Run(() =>
            {
                return new List<ForeignDonation>(){
                  new ForeignDonation()  { Id = 1, EntityName = "first entity", DonationAmount = 111.1 },
                  new ForeignDonation()  { Id = 2, EntityName = "second entity", DonationAmount = 222.22 },
                  new ForeignDonation()  { Id = 3, EntityName = "third entity", DonationAmount = 333.333 }
                 };

            });
        }

        public Task Update(ForeignDonation foreignDonation)
        {
            throw new NotImplementedException();
        }
    }
}
