﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Donations.Application;
using Donations.DTO;
using Donations.Extensions;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Donations.Controllers
{
    [ApiController]
    public class ForeignDonationController : BaseController
    {
        private readonly IForeignDonationService _foreignDonationService;

        public ForeignDonationController(ILogger<ForeignDonationController> logger,IMapper mapper,IForeignDonationService foreignDonationService) :
                                base(logger, mapper)
        {
            _foreignDonationService = foreignDonationService;
        }


        [HttpPost]
        [Route("Add")]
        public async Task<JsonResult> Add([FromBody] ForeignDonation foreignDonation)
        {
            Stopwatch timer = Stopwatch.StartNew();
            await _foreignDonationService.Add(Mapper.Map<Application.Models.ForeignDonation>(foreignDonation));
            Response<IDTO> responseDto = new Response<IDTO>()
            {
                Message = null,
                StatusCode = 0,
                Data = null
            };
            timer.Stop();

            JsonResult response = responseDto.ToJsonResponse();
            return response;

        }
        
        [HttpPost]
        [Route("Delete")]
        public async Task<JsonResult> Delete(int id)
        {
            Stopwatch timer = Stopwatch.StartNew();
            await _foreignDonationService.Delete(id);
            Response<IDTO> responseDto = new Response<IDTO>()
            {
                Message = null,
                StatusCode = 0,
                Data = null
            };
            timer.Stop();

            JsonResult response = responseDto.ToJsonResponse();
            return response;

        }

        [HttpGet]
        [Route("Get")]

        public async Task<JsonResult> Get(int id)
        {
            Stopwatch timer = Stopwatch.StartNew();
            Application.Models.ForeignDonation result = await _foreignDonationService.Get(id);
            Response<ForeignDonation> responseDto = new Response<ForeignDonation>()
            {
                Message = null,
                StatusCode = 0,
                Data = Mapper.Map<ForeignDonation>(result)
            };
            timer.Stop();

            JsonResult response = responseDto.ToJsonResponse();
            return response;

        }

        [HttpGet]
        [Route("GetAll")]
        public async Task<JsonResult> GetAll()
        {
            Stopwatch timer = Stopwatch.StartNew();
            List<Application.Models.ForeignDonation> result = await _foreignDonationService.GetAll();

            // ....
            Response<ForeignDonation> responseDto = new Response<ForeignDonation>()//TODO: list
            {
                Message = null,
                StatusCode = 0,
                Data = Mapper.Map<ForeignDonation>(result)
            };
            timer.Stop();

            JsonResult response = responseDto.ToJsonResponse();
            return response;

        }

        [HttpPost]
        [Route("Update")]
        public async Task<JsonResult> Update([FromBody] ForeignDonation foreignDonation)
        {
            Stopwatch timer = Stopwatch.StartNew();
            await _foreignDonationService.Update(Mapper.Map<Application.Models.ForeignDonation>(foreignDonation));
            Response<IDTO> responseDto = new Response<IDTO>()
            {
                Message = null,
                StatusCode = 0,
                Data = null
            };
            timer.Stop();

            JsonResult response = responseDto.ToJsonResponse();
            return response;

        }
    }
}