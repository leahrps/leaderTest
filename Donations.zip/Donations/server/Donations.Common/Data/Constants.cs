﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Donations.Common.Data
{
    public class Constants
    {
        public const int THANKYOU_EMAIL_AMOUNT = 10000;
        public const string EMAIL_SUBJECT = "Thank you!";
        public const string EMAIL_BODY = "Thank you for your large donation!";

        public class Logger
        {
            public const string APPLICATION_ERROR_ID = "ErrorID";
            public const string PROCESSAPI_ERROR_ID = "ProcessApiErrorID";
            public const string DURATION = "Duration";
            public const string CORREALTION_ID_REQUEST_KEY = "CorrelationId";
            public const string PROCESS_ID = "ProcessID";
            public const string PAYLOAD = "PayLoad";
        }



    }
}
