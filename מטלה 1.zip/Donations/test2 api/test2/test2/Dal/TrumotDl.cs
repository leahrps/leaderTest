﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using test2.Models;

namespace test2.Dal
{
    public class TrumotDl
    {
        //private TrumotEntities db = new TrumotEntities(); //בהנחה שזה מופע של החיבור ל SQL

        public string GetTruma(string EntityName, string EntityType, string CurrencyType, string DonationAmount, string DesignationDonation, string TermsDonation, string ExchangeRate)
        {
            string convertDonationAmount = DonationAmount.Replace("--", ".");
            double sum = Convert.ToDouble(convertDonationAmount);
            string convertExchangeRate = ExchangeRate.Replace("--", ".");

            if (sum > 10000)
            {
                SendEmail(sum);
            }
            Truma truma = new Truma();
            truma.EntityName = EntityName;
            truma.EntityType = EntityType;
            truma.CurrencyType = CurrencyType;
            truma.DonationAmount = sum;
            truma.DesignationDonation = DesignationDonation;
            truma.TermsDonation = TermsDonation;
            truma.ExchangeRate = ExchangeRate;
            if (truma != null)
            {
                try
                {
                    //הוספת תרומה ל SQL
                    //tbl_truma tblTruma = new tbl_truma();
                    //db.tbl_truma.Add(truma);
                    //db.SaveChanges();

                }
                catch (Exception)
                {
                    //כתיבה לקובץ לוג כלשהו על הצלחה או נפילה של ההוספה....
                    Console.WriteLine("נכשלה הוספת התרומה ל DB");
                    return "נכשלה ההוספה";
                }
            }
            return "התעדכן בהצלחה";
        }

        public string UpdateTruma(string EntityName, string EntityType, string CurrencyType, string DonationAmount, string DesignationDonation, string TermsDonation, string ExchangeRate, int index)
        {
            string convertDonationAmount = DonationAmount.Replace("--", ".");
            double sum = Convert.ToDouble(convertDonationAmount);
            string convertExchangeRate = ExchangeRate.Replace("--", ".");

           
            Truma truma = new Truma();
            truma.EntityName = EntityName;
            truma.EntityType = EntityType;
            truma.CurrencyType = CurrencyType;
            truma.DonationAmount = sum;
            truma.DesignationDonation = DesignationDonation;
            truma.TermsDonation = TermsDonation;
            truma.ExchangeRate = ExchangeRate;
            if (truma != null)
            {
                try
                {
                    //חיפוש האינדקס שב BD שם צריך לעדכן
                    //הוספת תרומה ל SQL
                    //tbl_truma tblTruma = new tbl_truma();
                    //db.tbl_truma.update(truma);
                    //db.SaveChanges();

                }
                catch (Exception)
                {
                    //כתיבה לקובץ לוג כלשהו על הצלחה או נפילה של ההוספה....
                    Console.WriteLine("נכשלה עידכון התרומה ל DB");
                    return "נכשלה העידכון";
                }
            }
            return "התעדכן בהצלחה";
        }

        public static void SendEmail(double DonationAmount)
        {
            try
            {

                MailMessage message = new MailMessage();
                SmtpClient smtp = new SmtpClient();
                message.From = new MailAddress("c0556797701@gmail.com");
                message.To.Add(new MailAddress("mirir1812@gmail.com"));
                message.Subject = "תרומה גבוהה";
                message.IsBodyHtml = true; //to make message body as html  
                message.Body = "התקבלה תרומה של " + " " + DonationAmount + " ש''ח ";
                smtp.Port = 587;
                smtp.Host = "smtp.gmail.com"; //for gmail host  
                smtp.EnableSsl = true;
                smtp.UseDefaultCredentials = false;
                smtp.Credentials = new NetworkCredential("c0556797701@gmail.com", "206504979");
                smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                smtp.Send(message);
            }
            catch (Exception e) {
                var a = e;
            }
        }


    }
}
  