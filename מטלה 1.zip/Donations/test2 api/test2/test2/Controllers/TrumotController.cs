﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using test2.Dal;

namespace test2.Controllers
{
    public class TrumotController : ApiController
    {


        //    הסיבה לשגיאה שלמעלה היא שאני משתמש ב-'/' נוסף בתכונת המסלול עבור הפעולה.הפעולה המוגדרת בבקר לעיל צריכה להיות כדלקמן:

        //[HttpGet]
        //    [Route("marketdata/tickerinfo")]
        //    public IHttpActionResult TickerInfo(string currencyPair)
        //    {

        //[AllowAnonymous]
        [HttpGet]
        [Route("api/Trumot/GetTruma/{EntityName}/{EntityType}/{CurrencyType}/{DonationAmount}/{DesignationDonation}/{TermsDonation}/{ExchangeRate}")]
        public string GetTruma(string EntityName, string EntityType, string CurrencyType, string DonationAmount, string DesignationDonation, string TermsDonation, string ExchangeRate)
        {
            Dal.TrumotDl DAL = new Dal.TrumotDl();
            return DAL.GetTruma(EntityName, EntityType, CurrencyType, DonationAmount, DesignationDonation, TermsDonation, ExchangeRate);
        }

        
        [HttpGet]
        [Route("api/Trumot/UpdateTruma/{EntityName}/{EntityType}/{CurrencyType}/{DonationAmount}/{DesignationDonation}/{TermsDonation}/{ExchangeRate}/{index}")]
        public string UpdateTruma(string EntityName, string EntityType, string CurrencyType, string DonationAmount, string DesignationDonation, string TermsDonation, string ExchangeRate,int index)
        {
            Dal.TrumotDl DAL = new Dal.TrumotDl();
            return DAL.UpdateTruma(EntityName, EntityType, CurrencyType, DonationAmount, DesignationDonation, TermsDonation, ExchangeRate,index);
        }
    }
}
