﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace test2.Models
{
    public class Truma
    {
        public string EntityName { get; set; }// שם ישות
        public string EntityType { get; set; }// סוג ישות
        public string CurrencyType { get; set; }//סוג מטבע
        public double DonationAmount { get; set; }//  סכום תרומה
        public string DesignationDonation { get; set; }//  ייעוד תרומה
        public string TermsDonation { get; set; }//  תנאי תרומה
        public string ExchangeRate { get; set; }//   שער המרה
    }
}

