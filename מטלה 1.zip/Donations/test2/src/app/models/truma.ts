export class Truma {
  EntityName: string; // שם ישות
  EntityType: string; // סוג ישות
  CurrencyType: string; //סוג מטבע
  DonationAmount: number; //  סכום תרומה
  DesignationDonation: string; //  ייעוד תרומה
  TermsDonation: string; //  תנאי תרומה
  ExchangeRate: number; //   שער המרה

  constructor() {
    this.EntityName = '';
    this.EntityType = '';
    this.CurrencyType = '';
    this.DonationAmount = 0;
    this.DesignationDonation = '';
    this.TermsDonation = '';
    this.ExchangeRate = 0;
  }
}
