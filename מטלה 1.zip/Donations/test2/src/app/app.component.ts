import { Component } from '@angular/core';
import { Truma } from './models/truma';
import { DataServiceService } from './services/data-service.service';

interface Currency {
  value: string;
  viewValue: string;
}

interface EntityType {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'test2';
  clickShow = false;

  constructor(private DataServiceService: DataServiceService) {}

  ngOnInit() {
    this.DataServiceService.listCurrencyType = [
      { value: 'usd-0', viewValue: 'USD' },
      { value: 'ils-1', viewValue: 'ILS' },
      { value: 'eur-2', viewValue: 'EUR' },
      { value: 'gbp-3', viewValue: 'GBP' },
      { value: 'aud-4', viewValue: 'AUD' },
      { value: 'rub-5', viewValue: 'RUB' },
    ];

    this.DataServiceService.listEntityType = [
      { value: '0', viewValue: '1' },
      { value: '1', viewValue: '2' },
      { value: '2', viewValue: '3' },
    ];

    this.DataServiceService.listTrumot = new Array<Truma>();
  }

  OpenTruma(event: any) {
    this.clickShow = true;
  }
}
