import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Truma } from '../models/truma';
import { DataServiceService } from '../services/data-service.service';
import { SendDataService } from "../services/send-data.service";
import { MatExpansionModule } from '@angular/material/expansion';
import { FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-show-trumot',
  templateUrl: './show-trumot.component.html',
  styleUrls: ['./show-trumot.component.css'],
})
export class ShowTrumotComponent implements OnInit {
  panelOpenState = false;
  @Output() addTruma =new EventEmitter();

  currency: any[] = [];
  entityType: any[] = [];
  listAllTrumor: Array<Truma> = new Array<Truma>();

  EntityNameFormControl = new FormControl('', Validators.required); // שם ישות
  EntityTypeFormControl = new FormControl('', Validators.required); // סוג ישות
  CurrencyTypeFormControl = new FormControl('', Validators.required); //סוג מטבע
  DonationAmountFormControl = new FormControl('', Validators.required); //  סכום תרומה
  DesignationDonationFormControl = new FormControl('', Validators.required); //  ייעוד תרומה
  ExchangeRateFormControl = new FormControl('', Validators.required); //   שער המרה
  TermsDonationFormControl: string = ''; //  תנאי תרומה

  constructor(private DataServiceService: DataServiceService,private SendDataService: SendDataService) {}
  ngOnInit(): void {
    this.listAllTrumor = this.DataServiceService.listTrumot;
    this.currency = this.DataServiceService.listCurrencyType;
    this.entityType = this.DataServiceService.listEntityType;
  }
  goToAddTruma() {
    this.addTruma.emit(true);
    debugger;
  }
  editTruma(item: Truma, index: number) {
      //במקרה ויש לבדוק האם המשתמש הוא זה הוסיף את הרשומה הייתי כאן בודקת את המשתמש....
    // ומאפשרת את העידכון רק אם אכן זה הוא....
    this.EntityNameFormControl.setValue(item.EntityName);
    this.DonationAmountFormControl.setValue(item.DonationAmount);
    this.EntityTypeFormControl.setValue(item.EntityType);
    this.DesignationDonationFormControl.setValue(item.DesignationDonation);
    this.CurrencyTypeFormControl.setValue(item.CurrencyType);
    this.ExchangeRateFormControl.setValue(item.ExchangeRate);
    this.TermsDonationFormControl = item.TermsDonation;
    // this.listAllTrumor.push(newTruma);
    // this.DataServiceService.listTrumot = this.listAllTrumor;
  }

  save(index: number) {
    debugger;
    if (
      !this.EntityNameFormControl.hasError('required') &&
      !this.DonationAmountFormControl.hasError('required') &&
      !this.EntityTypeFormControl.hasError('required') &&
      !this.DesignationDonationFormControl.hasError('required') &&
      !this.CurrencyTypeFormControl.hasError('required') &&
      !this.ExchangeRateFormControl.hasError('required')
    ) {
      var newTruma = new Truma();
      newTruma.EntityName = this.EntityNameFormControl.value;
      newTruma.DonationAmount = this.DonationAmountFormControl.value;
      newTruma.EntityType = this.EntityTypeFormControl.value;
      newTruma.DesignationDonation = this.DesignationDonationFormControl.value;
      newTruma.CurrencyType = this.CurrencyTypeFormControl.value;
      newTruma.ExchangeRate = this.ExchangeRateFormControl.value;
      newTruma.TermsDonation = this.TermsDonationFormControl;
      this.listAllTrumor[index] = newTruma;
      this.DataServiceService.listTrumot = this.listAllTrumor;
      console.log(this.listAllTrumor);
      this.SendDataService.UpdateTruma(newTruma,index).subscribe(
        (data: string) => {
          if (data != null) {
            alert('נוסף בהצלחה!');
          } else {
          }
          debugger;
        },
        (fail) => {}
      );
      debugger;    
    }
  }

  clean() {
    debugger;
    this.EntityNameFormControl.setValue('');
    this.DonationAmountFormControl.setValue('');
    this.EntityTypeFormControl.setValue('');
    this.DesignationDonationFormControl.setValue('');
    this.CurrencyTypeFormControl.setValue('');
    this.ExchangeRateFormControl.setValue('');
    this.TermsDonationFormControl = '';
    debugger;
  }

  onlyLettesKey(event: any) {
    var inp = String.fromCharCode(event.keyCode);

    if (/[a-zA-Zא-ת]/.test(inp)) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }

  onlyNumberOrKey(event: any) {
    // debugger
    // return event.charCode == 8 || event.charCode == 0 ||event.charCode == 46
    //   ? null
    //   : (event.charCode >= 48 && event.charCode <= 57) || event.charCode == 46;
    var charCode = event.which ? event.which : event.keyCode;
    if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57)) {
      event.preventDefault();
      return false;
    }
    return true;
  }
}
