import { Injectable } from '@angular/core';
import { Truma } from '../models/truma';

@Injectable({
  providedIn: 'root'
})
export class DataServiceService {

  
  private _listTrumot:Array<Truma>;
  public get listTrumot() : Array<Truma> {
    return this._listTrumot;
  }
  public set listTrumot(v : Array<Truma>) {
    this._listTrumot = v;
  }
  
  private _listCurrencyType:any[];
  public get listCurrencyType() : any[] {
    return this._listCurrencyType;
  }
  public set listCurrencyType(v : any[]) {
    this._listCurrencyType = v;
  }
  
  private  _listEntityType:any[];
  public get listEntityType() :any[] {
    return this._listEntityType;
  }
  public set listEntityType(v : any[]) {
    this._listEntityType = v;
  }
  
  constructor() {
    this._listTrumot=new Array<Truma>();
    this._listCurrencyType=new Array<any[]>();
    this._listEntityType=new Array<any[]>();
   }
}
