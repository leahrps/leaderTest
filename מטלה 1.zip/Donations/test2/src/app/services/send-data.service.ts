import { Injectable } from '@angular/core';
import {HttpClient, HttpResponse,HttpParams} from '@angular/common/http'
import { Observable, Subject } from 'rxjs';
// import { stringify } from 'querystring';
import { Truma } from "../models/truma";
@Injectable({

  providedIn: 'root'

})

 

export class SendDataService {
  url:String="";
  convertDonationAmount="";
  convertExchangeRate="";
  constructor(private httpClient:HttpClient) {
   }

  InsertTruma(truma:Truma) : Observable<any>{
    debugger;

    this.convertDonationAmount=truma["DonationAmount"].toString();
    this.convertDonationAmount=this.convertDonationAmount.replace(".","--");
    this.convertExchangeRate=truma["ExchangeRate"].toString();
    this.convertExchangeRate=this.convertExchangeRate.replace(".","--");

    // http://localhost:50502/api/Trumot/GetTruma/%D7%A9%D7%A9%D7%A9/%7BEntityType%7D/%7BCurrencyType%7D/%7BDonationAmount%7D/%7BDesignationDonation%7D/%7BTermsDonation%7D/%7BExchangeRate%7D
    // this.url = String("http://localhost/test2/api/Trumot/GetTruma/") 
    this.url = String("http://localhost:50502/api/Trumot/GetTruma/") 
    + truma["EntityName"]+"/"+truma["EntityType"]+"/"+truma["CurrencyType"]+"/"+this.convertDonationAmount+"/"+truma["DesignationDonation"]+"/"+truma["TermsDonation"]+"/"+this.convertExchangeRate;
    return this.httpClient.get<string[]>(String(this.url))
    debugger;

  }
  UpdateTruma(truma:Truma,index:number) : Observable<any>{
    debugger;

    this.convertDonationAmount=truma["DonationAmount"].toString();
    this.convertDonationAmount=this.convertDonationAmount.replace(".","--");
    this.convertExchangeRate=truma["ExchangeRate"].toString();
    this.convertExchangeRate=this.convertExchangeRate.replace(".","--");

    // http://localhost:50502/api/Trumot/GetTruma/%D7%A9%D7%A9%D7%A9/%7BEntityType%7D/%7BCurrencyType%7D/%7BDonationAmount%7D/%7BDesignationDonation%7D/%7BTermsDonation%7D/%7BExchangeRate%7D
    // this.url = String("http://localhost/test2/api/Trumot/GetTruma/") 
    this.url = String("http://localhost:50502/api/Trumot/UpdateTruma/") 
    + truma["EntityName"]+"/"+truma["EntityType"]+"/"+truma["CurrencyType"]+"/"+this.convertDonationAmount+"/"+truma["DesignationDonation"]+"/"+truma["TermsDonation"]+"/"+this.convertExchangeRate+"/"+index;
    return this.httpClient.get<string[]>(String(this.url))
    debugger;

  }

}