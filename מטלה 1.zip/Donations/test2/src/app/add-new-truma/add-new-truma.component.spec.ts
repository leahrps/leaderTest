import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddNewTrumaComponent } from './add-new-truma.component';

describe('AddNewTrumaComponent', () => {
  let component: AddNewTrumaComponent;
  let fixture: ComponentFixture<AddNewTrumaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddNewTrumaComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddNewTrumaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
