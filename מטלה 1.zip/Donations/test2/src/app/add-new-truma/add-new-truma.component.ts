import { Component, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Truma } from '../models/truma';
import { DataServiceService } from '../services/data-service.service';
import { SendDataService } from '../services/send-data.service';

// interface Currency {
//   value: string;
//   viewValue: string;
// }

// interface EntityType {
//   value: string;
//   viewValue: string;
// }
@Component({
  selector: 'app-add-new-truma',
  templateUrl: './add-new-truma.component.html',
  styleUrls: ['./add-new-truma.component.css'],
})
export class AddNewTrumaComponent implements OnInit {
  EntityNameFormControl = new FormControl('', Validators.required); // שם ישות
  EntityTypeFormControl = new FormControl('', Validators.required); // סוג ישות
  CurrencyTypeFormControl = new FormControl('', Validators.required); //סוג מטבע
  DonationAmountFormControl = new FormControl('', Validators.required); //  סכום תרומה
  DesignationDonationFormControl = new FormControl('', Validators.required); //  ייעוד תרומה
  // TermsDonationFormControl = new FormControl('', Validators.required); //  תנאי תרומה
  ExchangeRateFormControl = new FormControl('', Validators.required); //   שער המרה
  TermsDonationFormControl: string = ''; //  תנאי תרומה

  // currency: Currency[] = [
  //   { value: 'usa-0', viewValue: 'USA' },
  //   { value: 'ils-1', viewValue: 'ILS' },
  //   { value: 'earu-2', viewValue: 'EARU' },
  // ];

  // entityType: EntityType[] = [
  //   { value: 'usa-0', viewValue: 'USA' },
  //   { value: 'ils-1', viewValue: 'ILS' },
  //   { value: 'earu-2', viewValue: 'EARU' },
  // ];
  currency: any[] = [];
  entityType: any[] = [];
  listAllTrumor: Array<Truma> = new Array<Truma>();

  constructor(
    private DataServiceService: DataServiceService,
    private SendDataService: SendDataService
  ) {}

  ngOnInit(): void {
    this.currency = this.DataServiceService.listCurrencyType;
    this.entityType = this.DataServiceService.listEntityType;
    this.listAllTrumor = this.DataServiceService.listTrumot;
  }

  save() {
    debugger;
    if (
      !this.EntityNameFormControl.hasError('required') &&
      !this.DonationAmountFormControl.hasError('required') &&
      !this.EntityTypeFormControl.hasError('required') &&
      !this.DesignationDonationFormControl.hasError('required') &&
      !this.CurrencyTypeFormControl.hasError('required') &&
      !this.ExchangeRateFormControl.hasError('required')
    ) {
      var newTruma = new Truma();
      newTruma.EntityName = this.EntityNameFormControl.value;
      newTruma.DonationAmount = this.DonationAmountFormControl.value;
      newTruma.EntityType = this.EntityTypeFormControl.value;
      newTruma.DesignationDonation = this.DesignationDonationFormControl.value;
      newTruma.CurrencyType = this.CurrencyTypeFormControl.value;
      newTruma.ExchangeRate = this.ExchangeRateFormControl.value;
      newTruma.TermsDonation = this.TermsDonationFormControl;
      this.listAllTrumor.push(newTruma);
      this.DataServiceService.listTrumot = this.listAllTrumor;
      console.log(this.listAllTrumor);

      this.SendDataService.InsertTruma(newTruma).subscribe(
        (data: string) => {
          if (data != null) {
            alert('נוסף בהצלחה!');
          } else {
          }
          debugger;
        },
        (fail) => {}
      );
      debugger;
    }
  }
  clean() {
    debugger;
    this.EntityNameFormControl.setValue('');
    this.DonationAmountFormControl.setValue('');
    this.EntityTypeFormControl.setValue('');
    this.DesignationDonationFormControl.setValue('');
    this.CurrencyTypeFormControl.setValue('');
    this.ExchangeRateFormControl.setValue('');
    this.TermsDonationFormControl = '';
    debugger;
  }

  onlyLettesKey(event: any) {
    var inp = String.fromCharCode(event.keyCode);

    if (/[a-zA-Zא-ת]/.test(inp)) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }

  onlyNumberOrKey(event: any) {
    debugger;
    // return event.charCode == 8 || event.charCode == 0 ||event.charCode == 46 ? null
    //   : (event.charCode >= 48 && event.charCode <= 57) || event.charCode == 46;

    var charCode = event.which ? event.which : event.keyCode;
    if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57)) {
      event.preventDefault();
      return false;
    }
    return true;
  }
}
